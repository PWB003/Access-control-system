import subprocess
import os
import signal
import time

time.sleep(5)
subprocess.Popen(["python3", "cardmanage2.py"])