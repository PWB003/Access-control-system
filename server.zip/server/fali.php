// fail.php
<?php
// Display the failed login message
echo "<h1>Unauthorized Access: Not Logged In</h1>";
?>