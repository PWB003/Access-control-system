<?php


$host = 'localhost';
$user = 'cms';
$password = '123456';
$dbname = 'cmsdemo';